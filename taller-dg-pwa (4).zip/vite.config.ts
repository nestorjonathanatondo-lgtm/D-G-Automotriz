import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { VitePWA } from 'vite-plugin-pwa'

export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: 'autoUpdate',
      includeAssets: ['logo.jpg'],
      manifest: false, // usamos el nuestro en public
      workbox: {
        globPatterns: ['**/*.{js,css,html,ico,jpg,png,svg}']
      }
    })
  ]
})