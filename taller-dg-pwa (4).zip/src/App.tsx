import React, { useState, useEffect, useRef } from 'react';
// @ts-ignore
import logoUrl from "./assets/logo.jpg";

// --- TYPES ---
type Client = {
  id: string; nombre: string; tipo: 'particular'|'empresa'; telefono: string; email: string; direccion: string; rfc: string; notas: string; preferencias: string; tags: string[];
  visitas: number; createdAt: string;
}
type Vehicle = {
  id: string; clienteId: string; marca: string; modelo: string; matricula: string; vin: string; anio: number; color: string; km: number;
  fotos: string[]; docs: {itv?: string, seguro?: string}; historial: string[];
}
type DamagePoint = { id:string; view: 'frontal'|'trasera'|'izq'|'der'|'techo'; x:number; y:number; tipo:'rayon'|'abolladura'|'golpe'|'despintado'; severidad:'leve'|'medio'|'grave' };
type ChecklistItem = { id:string; nombre:string; valor:'B'|'M'|'R'|'' };
type OT = {
  id:string; clienteId:string; vehiculoId:string; fecha:string; diagnostico:string; descripcion:string;
  tiempoEst:number; tiempoReal:number; mecanico:string; prioridad:'baja'|'media'|'alta'|'urgente'; estado:'pendiente'|'en proceso'|'esperando piezas'|'finalizado'|'entregado';
  bahia:number; checklist: ChecklistItem[]; danos: DamagePoint[]; fotos: {antes:string[], durante:string[], despues:string[]};
  firmaCliente:string; firmaTecnico:string; total:number;
}
type Appointment = { id:string; clienteId:string; vehiculoId:string; fecha:string; hora:string; servicio:string; bahia:number; estado:'confirmada'|'espera'|'reprogramada'|'completada'; notas:string; }
type Part = { id:string; nombre:string; sku:string; stock:number; min: number; ubicacion:string; precio:number; proveedorId?:string };
type Supplier = { id:string; nombre:string; telefono:string; email:string; especialidad:string; };
type Employee = { id:string; nombre:string; rol:string; especialidad:string; horario:string; productividad:number; comisiones:number; };

// --- CONSTANTS ---
const CHECKLIST_BASE = [
  "Aceite motor", "Filtro aceite", "Frenos delanteros", "Frenos traseros", "Líquido frenos", "Llantas presión", "Llantas desgaste", "Batería", "Luces delanteras",
  "Luces traseras", "Intermitentes", "Limpiaparabrisas", "Anticongelante", "Correa distribución", "Amortiguadores", "Dirección", "Escape", "Clutch",
  "Transmisión", "Filtro aire", "Filtro combustible", "A/C gas", "Tablero testigos", "Bocina", "Cinturones", "Extintor / Kit", "Carrocería general", "Interior / tapicería"
];
const MECHANICS = ["Carlos Rivera", "José López", "Ana Torres", "Miguel Diesel"];
const SERVICES = ["Mantenimiento", "Diagnóstico electrónico", "Frenos", "Motor Diésel", "Inyección", "Suspensión", "A/C", "Transmisión"];

const demoClients: Client[] = [
  { id:'c1', nombre:'Juan Pérez', tipo:'particular', telefono:'5215551234567', email:'juan@mail.com', direccion:'Av. Reforma 123 CDMX', rfc:'PEJJ800101', notas:'Cliente frecuente, paga puntual', preferencias:'Aviso por WhatsApp', tags:['VIP','Diésel'], visitas:5, createdAt:'2024-01-15' },
  { id:'c2', nombre:'Transportes El Águila SA', tipo:'empresa', telefono:'5215559876543', email:'contacto@aguila.com', direccion:'Parque Industrial Qro', rfc:'TEA990202', notas:'Flotilla 12 unidades', preferencias:'Factura mensual', tags:['Flotilla','Empresa'], visitas:12, createdAt:'2023-11-20' },
  { id:'c3', nombre:'Laura Gómez', tipo:'particular', telefono:'5215552223333', email:'laura.g@mail.com', direccion:'Calle 5 #45 Puebla', rfc:'GOGL900505', notas:'Jetta 2020', preferencias:'Cita sábados', tags:['Gasolina'], visitas:2, createdAt:'2024-03-10' },
];
const demoVehicles: Vehicle[] = [
  { id:'v1', clienteId:'c1', marca:'Ford', modelo:'Ranger Diésel 3.2', matricula:'ABC-123', vin:'1FTFW1ET8DFA12345', anio:2021, color:'Blanco', km:85400, fotos:[], docs:{}, historial:['Cambio aceite 2024-06-01'] },
  { id:'v2', clienteId:'c2', marca:'Mercedes', modelo:'Sprinter 415', matricula:'XYZ-789', vin:'WDB9066331S123456', anio:2022, color:'Plata', km:112000, fotos:[], docs:{}, historial:['Frenos completos 2024-05-10'] },
  { id:'v3', clienteId:'c3', marca:'VW', modelo:'Jetta 1.4 TSI', matricula:'JTA-456', vin:'3VW2B7AJ1FM123456', anio:2020, color:'Negro', km:45000, fotos:[], docs:{}, historial:['Afinación mayor 2024-04-20'] },
];
const demoParts: Part[] = [
  { id:'p1', nombre:'Filtro aceite Diésel', sku:'FD-001', stock:8, min:5, ubicacion:'A1-01', precio:320 },
  { id:'p2', nombre:'Balatas delanteras Ranger', sku:'BR-202', stock:2, min:4, ubicacion:'B2-03', precio:1250 },
  { id:'p3', nombre:'Aceite 15W40 20L', sku:'AC-15W', stock:12, min:3, ubicacion:'C1-10', precio:1850 },
  { id:'p4', nombre:'Batería LTH 12V', sku:'BAT-LTH', stock:1, min:3, ubicacion:'A2-05', precio:2900 },
];

// --- COMPONENTS ---
function SignaturePad({ label, value, onSave }: { label:string, value:string, onSave:(data:string)=>void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const isDrawing = useRef(false);
  useEffect(()=> {
    const canvas = canvasRef.current; if(!canvas) return;
    const ctx = canvas.getContext('2d'); if(!ctx) return;
    ctx.lineWidth = 2; ctx.lineCap='round'; ctx.strokeStyle='#111';
    if(value){
      const img = new Image(); img.src=value;
      img.onload=()=>{ ctx.clearRect(0,0,canvas.width,canvas.height); ctx.drawImage(img,0,0); }
    } else { ctx.clearRect(0,0,canvas.width,canvas.height); }
  }, [value]);
  const getPos = (e:any) => {
    const canvas = canvasRef.current!; const rect = canvas.getBoundingClientRect();
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
    return { x: (clientX-rect.left)*(canvas.width/rect.width), y: (clientY-rect.top)*(canvas.height/rect.height) };
  };
  const start = (e:any)=>{ isDrawing.current=true; const {x,y}=getPos(e); const ctx=canvasRef.current!.getContext('2d')!; ctx.beginPath(); ctx.moveTo(x,y); e.preventDefault(); };
  const move = (e:any)=>{ if(!isDrawing.current) return; const {x,y}=getPos(e); const ctx=canvasRef.current!.getContext('2d')!; ctx.lineTo(x,y); ctx.stroke(); e.preventDefault(); };
  const end = ()=>{ if(!isDrawing.current) return; isDrawing.current=false; onSave(canvasRef.current!.toDataURL()); };
  const clear = ()=>{ const c=canvasRef.current!; c.getContext('2d')!.clearRect(0,0,c.width,c.height); onSave(''); };
  return (
    <div className="border rounded-xl p-3 bg-white">
      <div className="flex justify-between items-center mb-2"><span className="text-sm font-semibold">{label}</span><button onClick={clear} className="text-xs px-2 py-1 bg-zinc-100 rounded">Limpiar</button></div>
      <canvas ref={canvasRef} width={320} height={120} className="w-full h-[120px] border border-dashed rounded-lg bg-[#FFFCF8] touch-none cursor-crosshair"
        onMouseDown={start} onMouseMove={move} onMouseUp={end} onMouseLeave={end}
        onTouchStart={start} onTouchMove={move} onTouchEnd={end}
      />
      {value && <div className="text-[10px] text-green-700 mt-1">✓ Firma capturada</div>}
    </div>
  )
}

function DamageDiagram({ damages, setDamages }: { damages: DamagePoint[], setDamages: (d:DamagePoint[])=>void }) {
  const [view, setView] = useState<DamagePoint['view']>('frontal');
  const [tipo, setTipo] = useState<DamagePoint['tipo']>('rayon');
  const [sev, setSev] = useState<DamagePoint['severidad']>('leve');
  const views: DamagePoint['view'][] = ['frontal','trasera','izq','der','techo'];
  const addPoint = (e: React.MouseEvent<SVGSVGElement>)=>{
    const svg = e.currentTarget; const rect = svg.getBoundingClientRect();
    const x = ((e.clientX-rect.left)/rect.width)*100;
    const y = ((e.clientY-rect.top)/rect.height)*100;
    const newD: DamagePoint = { id: Date.now().toString(), view, x, y, tipo, severidad: sev };
    setDamages([...damages, newD]);
  };
  const colorMap = { leve:'#22c55e', medio:'#eab308', grave:'#dc2626' };
  const labelMap = { frontal:'Frontal', trasera:'Trasera', izq:'Lateral Izq', der:'Lateral Der', techo:'Superior / Techo' };
  return (
    <div className="grid md:grid-cols-[1fr_220px] gap-4">
      <div className="bg-white border rounded-xl p-3">
        <div className="flex gap-1 mb-3 flex-wrap">
          {views.map(v=> <button key={v} onClick={()=>setView(v)} className={`px-3 py-1 rounded-full text-xs font-bold border ${view===v?'bg-[#7A1C1C] text-white border-[#7A1C1C]':'bg-zinc-50'}`}>{labelMap[v]}</button>)}
        </div>
        <div className="flex gap-2 mb-3">
          <select value={tipo} onChange={e=>setTipo(e.target.value as any)} className="border rounded-lg px-2 py-1 text-xs">
            <option value="rayon">Rayón</option><option value="abolladura">Abolladura</option><option value="golpe">Golpe</option><option value="despintado">Despintado</option>
          </select>
          <select value={sev} onChange={e=>setSev(e.target.value as any)} className="border rounded-lg px-2 py-1 text-xs">
            <option value="leve">Leve - Verde</option><option value="medio">Medio - Amarillo</option><option value="grave">Grave - Rojo</option>
          </select>
        </div>
        <div className="relative bg-[#f9f7f4] rounded-xl border overflow-hidden aspect-[16/10] flex items-center justify-center">
          <svg viewBox="0 0 100 60" className="w-full h-full cursor-crosshair" onClick={addPoint}>
            {view==='frontal' && <><rect x="20" y="10" width="60" height="35" rx="8" fill="#e5e5e5" stroke="#111" strokeWidth="0.8"/><circle cx="30" cy="45" r="6" fill="#222"/><circle cx="70" cy="45" r="6" fill="#222"/><rect x="35" y="18" width="30" height="12" rx="2" fill="#C0C0C0" stroke="#111" strokeWidth="0.5"/></>}
            {view==='trasera' && <><rect x="20" y="10" width="60" height="35" rx="4" fill="#e5e5e5" stroke="#111" strokeWidth="0.8"/><rect x="25" y="15" width="50" height="20" rx="2" fill="#d4d4d4"/><circle cx="30" cy="45" r="6" fill="#222"/><circle cx="70" cy="45" r="6" fill="#222"/></>}
            {view==='izq' && <><path d="M10 30 Q 20 10 50 12 L 85 15 Q 90 25 90 35 L 50 38 Q 15 38 10 30" fill="#e5e5e5" stroke="#111" strokeWidth="0.8"/><circle cx="30" cy="38" r="6" fill="#222"/><circle cx="70" cy="38" r="6" fill="#222"/></>}
            {view==='der' && <><path d="M90 30 Q 80 10 50 12 L 15 15 Q 10 25 10 35 L 50 38 Q 85 38 90 30" fill="#e5e5e5" stroke="#111" strokeWidth="0.8"/><circle cx="70" cy="38" r="6" fill="#222"/><circle cx="30" cy="38" r="6" fill="#222"/></>}
            {view==='techo' && <><rect x="15" y="5" width="70" height="50" rx="12" fill="#e5e5e5" stroke="#111" strokeWidth="0.8"/><rect x="30" y="10" width="40" height="25" rx="4" fill="#C0C0C0" stroke="#111" strokeWidth="0.5"/></>}
            {damages.filter(d=>d.view===view).map(d=>(
              <g key={d.id}><circle cx={d.x} cy={d.y*0.6} r="2.2" fill={colorMap[d.severidad]} stroke="#fff" strokeWidth="0.5"/><text x={d.x+2.5} y={d.y*0.6-2} fontSize="3" fill="#111" fontWeight="bold">{d.tipo[0]}</text></g>
            ))}
          </svg>
          <div className="absolute bottom-2 left-2 text-[10px] bg-black/70 text-white px-2 py-1 rounded">Click para marcar daño • {damages.filter(d=>d.view===view).length} marcas</div>
        </div>
      </div>
      <div className="bg-white border rounded-xl p-3 flex flex-col">
        <h4 className="font-bold text-sm mb-2">Daños registrados ({damages.length})</h4>
        <div className="space-y-2 max-h-[260px] overflow-auto pr-1">
          {damages.length===0 && <div className="text-xs text-zinc-500">Sin daños. Haz click en el diagrama.</div>}
          {damages.map(d=>(
            <div key={d.id} className="flex items-center justify-between border rounded-lg px-2 py-1 text-xs">
              <div className="flex items-center gap-2"><span className="w-2 h-2 rounded-full" style={{background:colorMap[d.severidad]}}></span><span className="font-semibold">{d.view}</span> <span>{d.tipo}</span></div>
              <button onClick={()=>setDamages(damages.filter(x=>x.id!==d.id))} className="text-red-600">✕</button>
            </div>
          ))}
        </div>
        <div className="mt-auto pt-3 text-[11px] text-zinc-600">
          <div className="flex gap-2"><span className="w-3 h-3 bg-green-500 rounded-full"></span> Leve <span className="w-3 h-3 bg-yellow-400 rounded-full ml-2"></span> Medio <span className="w-3 h-3 bg-red-600 rounded-full ml-2"></span> Grave</div>
        </div>
      </div>
    </div>
  )
}

export default function App() {
  // persistence
  const [clients, setClients] = useState<Client[]>(()=>{ const s=localStorage.getItem('dg_clients'); return s? JSON.parse(s): demoClients; });
  const [vehicles, setVehicles] = useState<Vehicle[]>(()=>{ const s=localStorage.getItem('dg_vehicles'); return s? JSON.parse(s): demoVehicles; });
  const [ots, setOts] = useState<OT[]>(()=>{ const s=localStorage.getItem('dg_ots'); if(s) return JSON.parse(s); 
    return [
      { id:'OT-1001', clienteId:'c1', vehiculoId:'v1', fecha:new Date().toISOString(), diagnostico:'Ruido en suspensión delantera + testigo check engine', descripcion:'Revisión completa suspensión, escaneo y cambio amortiguadores', tiempoEst:6, tiempoReal:0, mecanico:'Carlos Rivera', prioridad:'alta', estado:'en proceso', bahia:1, checklist: CHECKLIST_BASE.map((n,i)=>({id:i.toString(), nombre:n, valor: (['B','B','M','B','B'] as any)[i%5]||'B'})), danos:[{id:'1', view:'frontal', x:32, y:28, tipo:'rayon', severidad:'leve'}], fotos:{antes:[], durante:[], despues:[]}, firmaCliente:'', firmaTecnico:'', total:4850 },
      { id:'OT-1002', clienteId:'c2', vehiculoId:'v2', fecha:new Date().toISOString(), diagnostico:'Frenos largos, mantenimiento preventivo 110k km', descripcion:'Cambio balatas, rectificado discos, cambio aceite y filtros', tiempoEst:4, tiempoReal:2, mecanico:'José López', prioridad:'media', estado:'esperando piezas', bahia:2, checklist: CHECKLIST_BASE.map((n,i)=>({id:i.toString(), nombre:n, valor:'B'})), danos:[], fotos:{antes:[], durante:[], despues:[]}, firmaCliente:'', firmaTecnico:'', total:7200 },
    ] as OT[];
  });
  const [appointments, setAppointments] = useState<Appointment[]>(()=>{ const s=localStorage.getItem('dg_appointments'); return s? JSON.parse(s): [{id:'a1', clienteId:'c1', vehiculoId:'v1', fecha:new Date().toISOString().slice(0,10), hora:'10:00', servicio:'Mantenimiento', bahia:1, estado:'confirmada', notas:'Traer factura'}] as Appointment[]; });
  const [parts, setParts] = useState<Part[]>(()=>{ const s=localStorage.getItem('dg_parts'); return s? JSON.parse(s): demoParts; });
  const [suppliers] = useState<Supplier[]>([{id:'s1', nombre:'Refaccionaria Central', telefono:'555 123 4567', email:'ventas@refac.com', especialidad:'Diésel'}, {id:'s2', nombre:'AutoPartes Express', telefono:'555 987 6543', email:'pedidos@autop.com', especialidad:'General'}]);
  const [employees] = useState<Employee[]>(MECHANICS.map((m,i)=>({id:'e'+i, nombre:m, rol:'Mecánico', especialidad: i%2?'Diésel':'Gasolina', horario:'8am-6pm', productividad: 85+i*3, comisiones:1200+i*200})));

  const [activeModule, setActiveModule] = useState('dashboard');
  const [searchClient, setSearchClient] = useState('');
  const [showClientModal, setShowClientModal] = useState(false);
  const [editingClient, setEditingClient] = useState<Client|null>(null);
  const [clientForm, setClientForm] = useState<Partial<Client>>({ tipo:'particular', tags:[] });

  const [showVehicleModal, setShowVehicleModal] = useState(false);
  const [editingVehicle, setEditingVehicle] = useState<Vehicle|null>(null);
  const [vehicleForm, setVehicleForm] = useState<Partial<Vehicle>>({});

  const [showOTForm, setShowOTForm] = useState(false);
  const [editingOT, setEditingOT] = useState<OT|null>(null);
  const [otForm, setOtForm] = useState<Partial<OT>>({ prioridad:'media', estado:'pendiente', bahia:1, checklist: CHECKLIST_BASE.map((n,i)=>({id:i.toString(), nombre:n, valor:'' as any})), danos:[], fotos:{antes:[], durante:[], despues:[]}, firmaCliente:'', firmaTecnico:'' });

  const [showAppointmentModal, setShowAppointmentModal] = useState(false);
  const [appointmentForm, setAppointmentForm] = useState<Partial<Appointment>>({ bahia:1, estado:'confirmada' });

  const [presupuestos, setPresupuestos] = useState<any[]>([{id:'P-2001', clienteId:'c3', vehiculoId:'v3', total:3200, validez:'2024-07-01', aprobado:false, items:[{desc:'Afinación mayor', qty:1, price:3200}]}]);
  const [showPresupuestoModal, setShowPresupuestoModal] = useState(false);

  const [mobileMenu, setMobileMenu] = useState(false);
  const [agendaView, setAgendaView] = useState<'dia'|'semana'|'mes'>('semana');
  const [notifOpen, setNotifOpen] = useState(false);
  const [facturas, setFacturas] = useState<any[]>([{id:'F-3001', otId:'OT-1001', cliente:'Juan Pérez', total:4850, estado:'pendiente', pago:'transferencia'}]);

  // save
  useEffect(()=>{ localStorage.setItem('dg_clients', JSON.stringify(clients)); }, [clients]);
  useEffect(()=>{ localStorage.setItem('dg_vehicles', JSON.stringify(vehicles)); }, [vehicles]);
  useEffect(()=>{ localStorage.setItem('dg_ots', JSON.stringify(ots)); }, [ots]);
  useEffect(()=>{ localStorage.setItem('dg_appointments', JSON.stringify(appointments)); }, [appointments]);
  useEffect(()=>{ localStorage.setItem('dg_parts', JSON.stringify(parts)); }, [parts]);

  // helpers
  const getClient = (id:string)=> clients.find(c=>c.id===id);
  const getVehicle = (id:string)=> vehicles.find(v=>v.id===id);

  // CRM actions
  const openNewClient = ()=>{ setEditingClient(null); setClientForm({ tipo:'particular', tags:[] }); setShowClientModal(true); };
  const openEditClient = (c:Client)=>{ setEditingClient(c); setClientForm(c); setShowClientModal(true); };
  const saveClient = ()=>{
    if(!clientForm.nombre || !clientForm.telefono) return alert('Nombre y teléfono requeridos');
    if(editingClient){
      setClients(clients.map(c=> c.id===editingClient.id ? {...c, ...clientForm} as Client : c));
    } else {
      const newC: Client = { id:'c'+Date.now(), nombre: clientForm.nombre!, tipo: clientForm.tipo as any || 'particular', telefono: clientForm.telefono!, email: clientForm.email||'', direccion: clientForm.direccion||'', rfc: clientForm.rfc||'', notas: clientForm.notas||'', preferencias: clientForm.preferencias||'', tags: clientForm.tags||[], visitas:0, createdAt:new Date().toISOString().slice(0,10) };
      setClients([newC, ...clients]);
    }
    setShowClientModal(false);
  };

  const saveVehicle = ()=>{
    if(!vehicleForm.marca || !vehicleForm.matricula || !vehicleForm.clienteId) return alert('Marca, matrícula y cliente requeridos');
    if(editingVehicle){
      setVehicles(vehicles.map(v=> v.id===editingVehicle.id ? {...v, ...vehicleForm} as Vehicle : v));
    } else {
      const newV: Vehicle = { id:'v'+Date.now(), clienteId: vehicleForm.clienteId!, marca: vehicleForm.marca!, modelo: vehicleForm.modelo||'', matricula: vehicleForm.matricula!, vin: vehicleForm.vin||'', anio: vehicleForm.anio||2020, color: vehicleForm.color||'', km: vehicleForm.km||0, fotos:[], docs:{}, historial:[] };
      setVehicles([newV, ...vehicles]);
    }
    setShowVehicleModal(false);
  };

  const saveOT = ()=>{
    if(!otForm.clienteId || !otForm.vehiculoId) return alert('Selecciona cliente y vehículo');
    if(editingOT){
      setOts(ots.map(o=> o.id===editingOT.id ? {...o, ...otForm} as OT : o));
    } else {
      const newOT: OT = { id:'OT-'+Math.floor(1000+Math.random()*9000), clienteId: otForm.clienteId!, vehiculoId: otForm.vehiculoId!, fecha: new Date().toISOString(), diagnostico: otForm.diagnostico||'', descripcion: otForm.descripcion||'', tiempoEst: otForm.tiempoEst||4, tiempoReal: otForm.tiempoReal||0, mecanico: otForm.mecanico||MECHANICS[0], prioridad: otForm.prioridad||'media', estado: otForm.estado||'pendiente', bahia: otForm.bahia||1, checklist: otForm.checklist||[], danos: otForm.danos||[], fotos: otForm.fotos||{antes:[], durante:[], despues:[]}, firmaCliente: otForm.firmaCliente||'', firmaTecnico: otForm.firmaTecnico||'', total: otForm.total||0 };
      setOts([newOT, ...ots]);
    }
    setShowOTForm(false); setEditingOT(null);
  };

  const saveAppointment = ()=>{
    if(!appointmentForm.clienteId || !appointmentForm.fecha) return alert('Cliente y fecha requeridos');
    const newA: Appointment = { id:'a'+Date.now(), clienteId: appointmentForm.clienteId!, vehiculoId: appointmentForm.vehiculoId||'', fecha: appointmentForm.fecha!, hora: appointmentForm.hora||'10:00', servicio: appointmentForm.servicio||'Mantenimiento', bahia: appointmentForm.bahia||1, estado: appointmentForm.estado as any||'confirmada', notas: appointmentForm.notas||'' };
    setAppointments([newA, ...appointments]); setShowAppointmentModal(false);
  };

  const handleFileUpload = (files: FileList|null, target: 'antes'|'durante'|'despues')=>{
    if(!files) return;
    Array.from(files).forEach(file=>{
      const reader = new FileReader();
      reader.onload = e=>{
        const url = e.target?.result as string;
        setOtForm(prev=> ({...prev, fotos:{...prev.fotos!, [target]: [...(prev.fotos as any)[target], url]}} as any));
      };
      reader.readAsDataURL(file);
    });
  };

  const generatePDFChecklist = (ot: OT)=>{
    const client = getClient(ot.clienteId); const vehicle = getVehicle(ot.vehiculoId);
    const win = window.open('', '_blank'); if(!win) return;
    const checklistRows = ot.checklist.map(c=> `<tr style="background:${c.valor==='B'?'#dcfce7':c.valor==='M'?'#fef9c3':c.valor==='R'?'#fee2e2':'#fff'}"><td style="padding:6px;border:1px solid #ddd">${c.nombre}</td><td style="padding:6px;border:1px solid #ddd;text-align:center;font-weight:bold">${c.valor}</td></tr>`).join('');
    const danosList = ot.danos.map(d=> `<li>${d.view} - ${d.tipo} (${d.severidad}) x:${d.x.toFixed(0)}% y:${d.y.toFixed(0)}%</li>`).join('');
    win.document.write(`
      <html><head><title>Checklist ${ot.id}</title><style>body{font-family:Arial;padding:20px;color:#111} .header{display:flex;justify-content:space-between;align-items:center;border-bottom:3px solid #7A1C1C;padding-bottom:10px} table{width:100%;border-collapse:collapse;margin-top:12px} .firmas{display:flex;gap:20px;margin-top:20px} .firma{flex:1;border:1px solid #ddd;padding:10px;text-align:center} img{max-width:100%}</style></head>
      <body>
        <div class="header"><div><h1 style="margin:0;color:#7A1C1C">Diésel & Gasolina Automotriz</h1><p style="margin:0">Checklist Recepción - ${ot.id}</p></div><img src="${logoUrl}" style="width:80px;height:80px;object-fit:contain;border-radius:50%;border:2px solid #7A1C1C"/></div>
        <p><b>Cliente:</b> ${client?.nombre} | <b>Tel:</b> ${client?.telefono} | <b>Vehículo:</b> ${vehicle?.marca} ${vehicle?.modelo} ${vehicle?.matricula} | <b>Fecha:</b> ${new Date(ot.fecha).toLocaleString()} | <b>Bahía:</b> ${ot.bahia} | <b>Mecánico:</b> ${ot.mecanico}</p>
        <p><b>Diagnóstico:</b> ${ot.diagnostico}<br/><b>Trabajo:</b> ${ot.descripcion}</p>
        <h3>Checklist 28 puntos (B=Bueno Verde, M=Mal Amarillo, R=Regular Rojo)</h3>
        <table><thead><tr><th style="text-align:left;padding:6px;border:1px solid #ddd;background:#7A1C1C;color:#fff">Concepto</th><th style="padding:6px;border:1px solid #ddd;background:#7A1C1C;color:#fff">B/M/R</th></tr></thead><tbody>${checklistRows}</tbody></table>
        <h3>Diagrama de Daños - ${ot.danos.length} marcas</h3><ul>${danosList || '<li>Sin daños</li>'}</ul>
        <h3>Fotografías</h3><div style="display:flex;gap:8px;flex-wrap:wrap">${[...ot.fotos.antes, ...ot.fotos.durante, ...ot.fotos.despues].map(f=>`<img src="${f}" style="width:120px;height:80px;object-fit:cover;border:1px solid #ddd;border-radius:6px"/>`).join('')}</div>
        <div class="firmas"><div class="firma"><p><b>Firma Cliente</b></p>${ot.firmaCliente?`<img src="${ot.firmaCliente}"/>`:'<p>Sin firma</p>'}<p>${client?.nombre}</p></div><div class="firma"><p><b>Firma Técnico</b></p>${ot.firmaTecnico?`<img src="${ot.firmaTecnico}"/>`:'<p>Sin firma</p>'}<p>${ot.mecanico}</p></div></div>
        <!-- Impresión manual desde el navegador -->
      </body></html>
    `);
    win.document.close();
  };

  const kpis = {
    ocupacion: Math.round((ots.filter(o=>o.estado==='en proceso').length/4)*100),
    facturacion: ots.reduce((s,o)=>s+o.total,0),
    otsActivas: ots.filter(o=>o.estado!=='entregado').length,
    vehiculosBahia: ots.filter(o=>o.estado==='en proceso').length,
    stockAlert: parts.filter(p=>p.stock<=p.min).length,
  };

  const navItems = [
    {id:'dashboard', label:'Dashboard', icon:'📊'},
    {id:'clientes', label:'Clientes CRM', icon:'👥'},
    {id:'vehiculos', label:'Vehículos', icon:'🚗'},
    {id:'agenda', label:'Citas & Agenda', icon:'📅'},
    {id:'ordenes', label:'Órdenes Trabajo', icon:'🛠️'},
    {id:'presupuestos', label:'Presupuestos', icon:'💰'},
    {id:'inventario', label:'Inventario', icon:'📦'},
    {id:'proveedores', label:'Proveedores', icon:'🏭'},
    {id:'personal', label:'Personal', icon:'👨‍🔧'},
    {id:'tiempos', label:'Tiempos', icon:'⏱️'},
    {id:'facturacion', label:'Facturación', icon:'🧾'},
    {id:'bahias', label:'Bahías / Recursos', icon:'🏗️'},
    {id:'movil', label:'Móvil Técnico', icon:'📱'},
    {id:'informes', label:'Informes', icon:'📈'},
    {id:'config', label:'Configuración', icon:'⚙️'},
  ];

  return (
    <div className="min-h-screen bg-[#f5f5f5] text-zinc-900 font-sans flex">
      {/* Sidebar */}
      <aside className={`fixed z-40 lg:static inset-y-0 left-0 w-[280px] bg-[#111] text-white flex flex-col transition-transform ${mobileMenu?'translate-x-0':'-translate-x-full lg:translate-x-0'}`}>
        <div className="p-4 flex items-center gap-3 border-b border-zinc-800">
          <img src={logoUrl} alt="logo" className="w-12 h-12 rounded-full object-cover border-2 border-[#8B1F2B] bg-[#7A1C1C]" />
          <div><div className="font-black leading-tight">DIÉSEL &<br/>GASOLINA</div><div className="text-[10px] tracking-[0.2em] text-zinc-400">AUTOMOTRIZ</div></div>
        </div>
        <nav className="flex-1 overflow-auto p-2 space-y-1">
          {navItems.map(item=>(
            <button key={item.id} onClick={()=>{setActiveModule(item.id); setMobileMenu(false); try{window.location.hash=item.id;}catch{}}} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition ${activeModule===item.id?'bg-[#7A1C1C] text-white shadow':'text-zinc-400 hover:text-white hover:bg-zinc-900'}`}>
              <span>{item.icon}</span>{item.label}{item.id==='ordenes' && <span className="ml-auto bg-white text-[#7A1C1C] text-[10px] px-2 py-0.5 rounded-full font-bold">{ots.length}</span>}
            </button>
          ))}
        </nav>
        <div className="p-3 border-t border-zinc-800">
          <div className="bg-zinc-900 rounded-xl p-3 flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-[#7A1C1C] flex items-center justify-center font-bold">A</div>
            <div className="text-xs"><div className="font-bold">Admin Taller</div><div className="text-zinc-500">Propietario</div></div>
          </div>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <header className="h-[64px] bg-white border-b flex items-center justify-between px-4 lg:px-6 sticky top-0 z-30">
          <div className="flex items-center gap-3">
            <button onClick={()=>setMobileMenu(!mobileMenu)} className="lg:hidden w-9 h-9 rounded-lg bg-zinc-900 text-white flex items-center justify-center">☰</button>
            <div className="hidden lg:flex items-center gap-2"><img src={logoUrl} className="w-8 h-8 rounded-full bg-[#7A1C1C] object-cover" /><span className="font-black text-[#7A1C1C]">D&G Automotriz</span><span className="text-zinc-400 text-sm">| Panel Profesional</span></div>
            <div className="lg:hidden font-bold">D&G Automotriz</div>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={()=>setNotifOpen(!notifOpen)} className="relative w-9 h-9 rounded-full bg-zinc-100 flex items-center justify-center">🔔{kpis.stockAlert>0 && <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-600 text-white text-[10px] rounded-full flex items-center justify-center">{kpis.stockAlert}</span>}</button>
            <div className="w-9 h-9 rounded-full bg-[#7A1C1C] text-white flex items-center justify-center font-bold">A</div>
          </div>
        </header>

        {/* Notifications */}
        {notifOpen && (
          <div className="absolute top-[64px] right-4 w-[320px] bg-white border shadow-xl rounded-2xl z-50 p-3">
            <h4 className="font-bold text-sm mb-2">Alertas</h4>
            <div className="space-y-2 text-xs">
              {parts.filter(p=>p.stock<=p.min).map(p=> <div key={p.id} className="p-2 bg-red-50 border border-red-100 rounded-lg">⚠️ Stock bajo: {p.nombre} ({p.stock})</div>)}
              {ots.filter(o=>o.estado==='esperando piezas').map(o=> <div key={o.id} className="p-2 bg-yellow-50 border border-yellow-100 rounded-lg">⏳ OT {o.id} esperando piezas</div>)}
              {ots.filter(o=>o.prioridad==='urgente').map(o=> <div key={o.id} className="p-2 bg-[#7A1C1C]/10 border border-[#7A1C1C]/20 rounded-lg">🚨 OT {o.id} urgente</div>)}
              {parts.filter(p=>p.stock<=p.min).length===0 && ots.filter(o=>o.estado==='esperando piezas').length===0 && <div className="text-zinc-500">Sin alertas</div>}
            </div>
          </div>
        )}

        {/* Content */}
        <main className="p-4 lg:p-6 flex-1 overflow-auto w-full max-w-full overflow-x-hidden">
          {activeModule==='dashboard' && (
            <div className="space-y-6">
              <h1 className="text-2xl font-black">Dashboard Taller</h1>
              <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
                <div className="bg-white border rounded-2xl p-4 shadow-sm"><div className="text-[11px] text-zinc-500 uppercase font-bold">Ocupación</div><div className="text-2xl font-black mt-1">{kpis.ocupacion}%</div><div className="mt-2 h-1.5 bg-zinc-100 rounded-full overflow-hidden"><div className="h-full bg-[#7A1C1C]" style={{width:kpis.ocupacion+'%'}}/></div></div>
                <div className="bg-white border rounded-2xl p-4 shadow-sm"><div className="text-[11px] text-zinc-500 uppercase font-bold">Facturación mes</div><div className="text-2xl font-black mt-1">${kpis.facturacion.toLocaleString()}</div><div className="text-xs text-green-600 mt-1">↑ 12% vs mes anterior</div></div>
                <div className="bg-white border rounded-2xl p-4 shadow-sm"><div className="text-[11px] text-zinc-500 uppercase font-bold">OTs activas</div><div className="text-2xl font-black mt-1">{kpis.otsActivas}</div><div className="flex gap-1 mt-2">{ots.map(o=> <div key={o.id} className={`h-1 flex-1 rounded ${o.estado==='en proceso'?'bg-[#7A1C1C]':o.estado==='pendiente'?'bg-zinc-300':'bg-green-500'}`} />)}</div></div>
                <div className="bg-white border rounded-2xl p-4 shadow-sm"><div className="text-[11px] text-zinc-500 uppercase font-bold">Vehículos en bahía</div><div className="text-2xl font-black mt-1">{kpis.vehiculosBahia}/4</div><div className="text-xs text-zinc-500 mt-1">Bahías ocupadas</div></div>
                <div className="bg-white border rounded-2xl p-4 shadow-sm border-red-200"><div className="text-[11px] text-red-600 uppercase font-bold">Alertas stock</div><div className="text-2xl font-black mt-1 text-red-600">{kpis.stockAlert}</div><div className="text-xs text-zinc-500 mt-1">Reposición urgente</div></div>
              </div>

              <div className="grid lg:grid-cols-3 gap-4">
                <div className="lg:col-span-2 bg-white border rounded-2xl p-5 shadow-sm">
                  <h3 className="font-bold mb-4">Facturación últimos 6 meses (visual)</h3>
                  <div className="flex items-end gap-2 h-[120px]">
                    {[4200, 6800, 5100, 7200, 8900, kpis.facturacion].map((v,i)=>(
                      <div key={i} className="flex-1 flex flex-col items-center gap-1"><div className="w-full bg-zinc-100 rounded-t-lg relative" style={{height:'100px'}}><div className="absolute bottom-0 w-full bg-[#7A1C1C] rounded-t-lg" style={{height: `${(v/10000)*100}%`}} /></div><span className="text-[10px]">{['Feb','Mar','Abr','May','Jun','Jul'][i]}</span></div>
                    ))}
                  </div>
                </div>
                <div className="bg-[#111] text-white rounded-2xl p-5 shadow-sm">
                  <h3 className="font-bold mb-3">Bahías en tiempo real</h3>
                  <div className="grid grid-cols-2 gap-2">
                    {[1,2,3,4].map(n=>{
                      const ot = ots.find(o=>o.bahia===n && o.estado==='en proceso');
                      return <div key={n} className={`rounded-xl p-3 border ${ot?'bg-[#7A1C1C] border-[#8B1F2B]':'bg-zinc-900 border-zinc-800'}`}><div className="text-[10px] opacity-70">BAHÍA {n}</div><div className="font-bold text-sm mt-1">{ot? ot.id : 'Libre'}</div><div className="text-[11px] opacity-60 mt-1">{ot? getVehicle(ot.vehiculoId)?.matricula : 'Disponible'}</div></div>
                    })}
                  </div>
                </div>
              </div>

              <div className="grid lg:grid-cols-2 gap-4">
                <div className="bg-white border rounded-2xl p-5"><h3 className="font-bold mb-3">OTs recientes</h3><div className="space-y-2">{ots.slice(0,4).map(o=>{const v=getVehicle(o.vehiculoId); return <div key={o.id} className="flex justify-between items-center border rounded-xl px-3 py-2"><div><div className="font-bold text-sm">{o.id} - {v?.marca} {v?.modelo}</div><div className="text-xs text-zinc-500">{o.estado} • Bahía {o.bahia}</div></div><span className={`text-[10px] px-2 py-1 rounded-full font-bold ${o.prioridad==='alta'?'bg-red-100 text-red-700':o.prioridad==='urgente'?'bg-red-600 text-white':'bg-zinc-100'}`}>{o.prioridad}</span></div>})}</div></div>
                <div className="bg-white border rounded-2xl p-5"><h3 className="font-bold mb-3">Stock crítico</h3><div className="space-y-2">{parts.filter(p=>p.stock<=p.min).map(p=> <div key={p.id} className="flex justify-between items-center border rounded-xl px-3 py-2 bg-red-50"><div><div className="font-bold text-sm">{p.nombre}</div><div className="text-xs">{p.ubicacion} • Min {p.min}</div></div><div className="font-black text-red-600">{p.stock}</div></div>)} {parts.filter(p=>p.stock<=p.min).length===0 && <div className="text-sm text-zinc-500">Todo en orden</div>}</div></div>
              </div>
            </div>
          )}

          {activeModule==='clientes' && (
            <div className="space-y-4">
              <div className="flex flex-wrap justify-between items-center gap-2"><h1 className="text-2xl font-black">Clientes CRM</h1><button onClick={openNewClient} className="bg-[#7A1C1C] text-white px-4 py-2 rounded-xl font-bold text-sm">+ Nuevo cliente</button></div>
              <div className="bg-white border rounded-2xl p-3 flex gap-2"><input value={searchClient} onChange={e=>setSearchClient(e.target.value)} placeholder="Buscar por nombre, teléfono, RFC..." className="flex-1 border rounded-xl px-3 py-2 text-sm outline-none"/><select className="border rounded-xl px-2 text-sm"><option>Todos</option><option>Particular</option><option>Empresa</option></select></div>
              <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-3">
                {clients.filter(c=> c.nombre.toLowerCase().includes(searchClient.toLowerCase()) || c.telefono.includes(searchClient)).map(c=>(
                  <div key={c.id} className="bg-white border rounded-2xl p-4 shadow-sm">
                    <div className="flex justify-between"><div><div className="font-bold">{c.nombre}</div><div className="text-xs text-zinc-500">{c.tipo} • {c.visitas} visitas</div></div><span className="text-[10px] bg-zinc-100 px-2 py-1 rounded-full h-fit">{c.tags[0]||'General'}</span></div>
                    <div className="mt-3 text-xs space-y-1 text-zinc-600"><div>📞 {c.telefono} • {c.email}</div><div>📍 {c.direccion}</div><div>Notas: {c.notas}</div></div>
                    <div className="mt-3 flex gap-2"><button onClick={()=>openEditClient(c)} className="flex-1 border rounded-xl py-1.5 text-xs font-bold">Editar</button>
                      <a href={`https://wa.me/${c.telefono.replace(/\D/g,'')}?text=${encodeURIComponent(`Hola ${c.nombre}, te recordamos tu cita en D&G Automotriz el ${new Date().toLocaleDateString()}. ¿Confirmas?`)}`} target="_blank" rel="noreferrer" className="flex-1 bg-[#25D366] text-white rounded-xl py-1.5 text-xs font-bold text-center">WhatsApp</a>
                      <a href={`tel:${c.telefono}`} className="w-9 h-9 border rounded-xl flex items-center justify-center text-xs">📞</a>
                    </div>
                    <div className="mt-3 text-[11px]"><span className="font-bold">Vehículos:</span> {vehicles.filter(v=>v.clienteId===c.id).map(v=>v.matricula).join(', ') || 'Sin vehículos'}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeModule==='vehiculos' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center"><h1 className="text-2xl font-black">Vehículos</h1><button onClick={()=>{setEditingVehicle(null); setVehicleForm({}); setShowVehicleModal(true);}} className="bg-[#7A1C1C] text-white px-4 py-2 rounded-xl font-bold text-sm">+ Nuevo vehículo</button></div>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
                {vehicles.map(v=>{
                  const cli=getClient(v.clienteId);
                  return <div key={v.id} className="bg-white border rounded-2xl p-4"><div className="flex justify-between"><div className="font-bold">{v.marca} {v.modelo}</div><span className="text-xs bg-zinc-100 px-2 py-1 rounded-full">{v.anio}</span></div><div className="text-xs text-zinc-600 mt-1">{v.matricula} • VIN {v.vin.slice(0,8)}... • {v.color} • {v.km.toLocaleString()} km</div><div className="text-xs mt-2">👤 {cli?.nombre} • {cli?.telefono}</div><div className="mt-2 text-[11px] bg-zinc-50 p-2 rounded-xl">Historial: {v.historial[0]||'Sin historial'}</div><button onClick={()=>{setEditingVehicle(v); setVehicleForm(v); setShowVehicleModal(true);}} className="mt-3 w-full border rounded-xl py-1.5 text-xs font-bold">Editar / Docs</button></div>
                })}
              </div>
            </div>
          )}

          {activeModule==='agenda' && (
            <div className="space-y-4">
              <div className="flex flex-wrap justify-between gap-2"><h1 className="text-2xl font-black">Citas & Agenda</h1><div className="flex gap-2"><div className="flex bg-zinc-100 rounded-xl p-1">{(['dia','semana','mes'] as const).map(v=> <button key={v} onClick={()=>setAgendaView(v)} className={`px-3 py-1 rounded-lg text-xs font-bold capitalize ${agendaView===v?'bg-white shadow':''}`}>{v}</button>)}<button onClick={()=>{setAppointmentForm({bahia:1}); setShowAppointmentModal(true);}} className="bg-[#7A1C1C] text-white px-4 py-2 rounded-xl font-bold text-sm ml-2">+ Cita</button></div></div></div>
              <div className="grid lg:grid-cols-[1fr_320px] gap-4">
                <div className="bg-white border rounded-2xl p-4">
                  <div className="flex gap-2 mb-3 overflow-auto">{[...Array(7)].map((_,i)=>{const d=new Date(); d.setDate(d.getDate()+i-3); return <div key={i} className="min-w-[90px] border rounded-xl p-2 text-center"><div className="text-[11px]">{d.toLocaleDateString('es-MX',{weekday:'short'})}</div><div className="font-bold">{d.getDate()}</div><div className="text-[10px] mt-1">{appointments.filter(a=>a.fecha===d.toISOString().slice(0,10)).length} citas</div></div>})}</div>
                  <div className="space-y-2">{appointments.map(a=>{const cl=getClient(a.clienteId); const ve=getVehicle(a.vehiculoId); return <div key={a.id} className="border rounded-xl p-3 flex justify-between items-center"><div><div className="font-bold text-sm">{a.hora} - {cl?.nombre} • {ve?.matricula}</div><div className="text-xs text-zinc-600">{a.servicio} • Bahía {a.bahia} • {a.estado}</div></div><div className="flex gap-1"><a href={`https://wa.me/${cl?.telefono.replace(/\D/g,'')}?text=${encodeURIComponent(`Hola ${cl?.nombre}, recordatorio cita ${a.fecha} ${a.hora} en D&G. Bahía ${a.bahia}.`)}`} target="_blank" className="w-8 h-8 bg-[#25D366] text-white rounded-full flex items-center justify-center text-xs">W</a><a href={`tel:${cl?.telefono}`} className="w-8 h-8 border rounded-full flex items-center justify-center text-xs">📞</a></div></div>})}</div>
                </div>
                <div className="space-y-3">
                  <div className="bg-[#111] text-white rounded-2xl p-4"><h3 className="font-bold mb-3">Bahías (4)</h3><div className="grid grid-cols-2 gap-2">{[1,2,3,4].map(n=>{const occ = appointments.some(a=>a.bahia===n) || ots.some(o=>o.bahia===n && o.estado==='en proceso'); return <div key={n} className={`p-3 rounded-xl border text-center ${occ?'bg-[#7A1C1C] border-[#8B1F2B]':'bg-zinc-900'}`}><div className="text-xs">Bahía {n}</div><div className="font-bold mt-1">{occ?'Ocupada':'Libre'}</div></div>})}</div><div className="mt-3 text-xs text-zinc-400">Capacidad: {appointments.length}/12 turnos hoy</div></div>
                  <div className="bg-white border rounded-2xl p-4"><h3 className="font-bold text-sm mb-2">Lista espera</h3><div className="text-xs text-zinc-500">Sin espera • Reprogramación drag & drop simulado arrastrando citas</div></div>
                </div>
              </div>
            </div>
          )}

          {activeModule==='ordenes' && (
            <div className="space-y-4">
              {!showOTForm ? (
                <>
                  <div className="flex justify-between items-center"><h1 className="text-2xl font-black">Órdenes de Trabajo</h1><button onClick={()=>{setEditingOT(null); setOtForm({ prioridad:'media', estado:'pendiente', bahia:1, checklist: CHECKLIST_BASE.map((n,i)=>({id:i.toString(), nombre:n, valor:'' as any})), danos:[], fotos:{antes:[], durante:[], despues:[]}, firmaCliente:'', firmaTecnico:'', tiempoEst:4}); setShowOTForm(true);}} className="bg-[#7A1C1C] text-white px-4 py-2 rounded-xl font-bold text-sm">+ Nueva OT</button></div>
                  <div className="grid md:grid-cols-2 gap-3">
                    {ots.map(ot=>{
                      const cl=getClient(ot.clienteId); const ve=getVehicle(ot.vehiculoId);
                      return <div key={ot.id} className="bg-white border rounded-2xl p-4 shadow-sm"><div className="flex justify-between"><div className="font-black">{ot.id}</div><span className={`text-[10px] px-2 py-1 rounded-full font-bold ${ot.estado==='en proceso'?'bg-[#7A1C1C] text-white':ot.estado==='pendiente'?'bg-zinc-200':ot.estado==='esperando piezas'?'bg-yellow-100 text-yellow-800':'bg-green-100 text-green-800'}`}>{ot.estado}</span></div><div className="text-sm mt-1">{cl?.nombre} • {ve?.marca} {ve?.modelo} {ve?.matricula}</div><div className="text-xs text-zinc-600 mt-1">{ot.diagnostico}</div><div className="flex gap-2 mt-3"><button onClick={()=>{setEditingOT(ot); setOtForm(ot); setShowOTForm(true);}} className="flex-1 border rounded-xl py-1.5 text-xs font-bold">Abrir / Editar</button><button onClick={()=>generatePDFChecklist(ot)} className="flex-1 bg-zinc-900 text-white rounded-xl py-1.5 text-xs font-bold">PDF Checklist</button></div></div>
                    })}
                  </div>
                </>
              ) : (
                <div className="bg-white border rounded-2xl p-4 lg:p-6 space-y-6">
                  <div className="flex justify-between items-center"><h2 className="text-xl font-black">{editingOT? 'Editar':'Nueva'} Orden - Checklist Recepción Profesional</h2><button onClick={()=>setShowOTForm(false)} className="border rounded-xl px-3 py-1 text-sm">Cerrar</button></div>

                  <div className="grid md:grid-cols-3 gap-3">
                    <div><label className="text-xs font-bold">Cliente</label><select value={otForm.clienteId||''} onChange={e=>setOtForm({...otForm, clienteId:e.target.value})} className="w-full border rounded-xl px-3 py-2 text-sm"><option value="">Seleccionar</option>{clients.map(c=> <option key={c.id} value={c.id}>{c.nombre}</option>)}</select></div>
                    <div><label className="text-xs font-bold">Vehículo (filtrado)</label><select value={otForm.vehiculoId||''} onChange={e=>setOtForm({...otForm, vehiculoId:e.target.value})} className="w-full border rounded-xl px-3 py-2 text-sm"><option value="">Seleccionar</option>{vehicles.filter(v=> !otForm.clienteId || v.clienteId===otForm.clienteId).map(v=> <option key={v.id} value={v.id}>{v.marca} {v.modelo} {v.matricula}</option>)}</select></div>
                    <div><label className="text-xs font-bold">Bahía / Elevador</label><select value={otForm.bahia} onChange={e=>setOtForm({...otForm, bahia: parseInt(e.target.value)})} className="w-full border rounded-xl px-3 py-2 text-sm">{[1,2,3,4].map(n=> <option key={n} value={n}>Bahía {n}</option>)}</select></div>
                    <div className="md:col-span-2"><label className="text-xs font-bold">Diagnóstico inicial</label><input value={otForm.diagnostico||''} onChange={e=>setOtForm({...otForm, diagnostico:e.target.value})} className="w-full border rounded-xl px-3 py-2 text-sm" placeholder="Ruido, testigo, fuga..."/></div>
                    <div><label className="text-xs font-bold">Mecánico</label><select value={otForm.mecanico} onChange={e=>setOtForm({...otForm, mecanico:e.target.value})} className="w-full border rounded-xl px-3 py-2 text-sm">{MECHANICS.map(m=> <option key={m} value={m}>{m}</option>)}</select></div>
                    <div><label className="text-xs font-bold">Prioridad</label><select value={otForm.prioridad} onChange={e=>setOtForm({...otForm, prioridad:e.target.value as any})} className="w-full border rounded-xl px-3 py-2 text-sm"><option value="baja">Baja</option><option value="media">Media</option><option value="alta">Alta</option><option value="urgente">Urgente</option></select></div>
                    <div><label className="text-xs font-bold">Estado</label><select value={otForm.estado} onChange={e=>setOtForm({...otForm, estado:e.target.value as any})} className="w-full border rounded-xl px-3 py-2 text-sm"><option value="pendiente">Pendiente</option><option value="en proceso">En proceso</option><option value="esperando piezas">Esperando piezas</option><option value="finalizado">Finalizado</option><option value="entregado">Entregado</option></select></div>
                    <div><label className="text-xs font-bold">Tiempo est (h)</label><input type="number" value={otForm.tiempoEst||0} onChange={e=>setOtForm({...otForm, tiempoEst: parseFloat(e.target.value)})} className="w-full border rounded-xl px-3 py-2 text-sm"/></div>
                    <div className="md:col-span-3"><label className="text-xs font-bold">Descripción trabajos</label><textarea value={otForm.descripcion||''} onChange={e=>setOtForm({...otForm, descripcion:e.target.value})} className="w-full border rounded-xl px-3 py-2 text-sm" rows={2}/></div>
                  </div>

                  <div>
                    <h3 className="font-black mb-2">Checklist Recepción 28 puntos - B Bueno (verde) / M Mal (amarillo) / R Regular (rojo)</h3>
                    <div className="grid md:grid-cols-2 gap-2 max-h-[360px] overflow-auto border rounded-xl p-2">
                      {otForm.checklist?.map((item, idx)=>(
                        <div key={item.id} className={`flex justify-between items-center border rounded-xl px-3 py-2 text-sm ${item.valor==='B'?'bg-green-50 border-green-200':item.valor==='M'?'bg-yellow-50 border-yellow-200':item.valor==='R'?'bg-red-50 border-red-200':'bg-white'}`}>
                          <span className="font-medium text-xs">{idx+1}. {item.nombre}</span>
                          <select value={item.valor} onChange={e=>{
                            const newList = [...(otForm.checklist||[])]; newList[idx] = {...item, valor: e.target.value as any}; setOtForm({...otForm, checklist:newList});
                          }} className="border rounded-lg px-2 py-1 text-xs font-bold">
                            <option value="">-</option><option value="B">B Bueno</option><option value="M">M Mal</option><option value="R">R Regular</option>
                          </select>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h3 className="font-black mb-2">Diagrama de daños - 5 vistas realistas</h3>
                    <DamageDiagram damages={otForm.danos||[]} setDamages={(d)=>setOtForm({...otForm, danos:d})} />
                  </div>

                  <div className="grid md:grid-cols-3 gap-3">
                    {(['antes','durante','despues'] as const).map(cat=>(
                      <div key={cat} className="border rounded-xl p-3"><div className="font-bold text-xs uppercase mb-2">Fotos {cat}</div><input type="file" multiple accept="image/*" onChange={e=>handleFileUpload(e.target.files, cat)} className="text-xs w-full"/><div className="flex flex-wrap gap-1 mt-2">{(otForm.fotos as any)?.[cat]?.map((f:string,i:number)=><img key={i} src={f} className="w-16 h-12 object-cover rounded border" />)}</div></div>
                    ))}
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <SignaturePad label="Firma Cliente - Recepción" value={otForm.firmaCliente||''} onSave={(d)=>setOtForm({...otForm, firmaCliente:d})} />
                    <SignaturePad label="Firma Técnico - Recepción" value={otForm.firmaTecnico||''} onSave={(d)=>setOtForm({...otForm, firmaTecnico:d})} />
                  </div>

                  <div className="flex gap-2">
                    <button onClick={saveOT} className="bg-[#7A1C1C] text-white px-6 py-2.5 rounded-xl font-bold">Guardar OT</button>
                    <button onClick={()=>{ if(otForm) generatePDFChecklist(otForm as OT); }} className="bg-zinc-900 text-white px-6 py-2.5 rounded-xl font-bold">Generar PDF Checklist</button>
                    <div className="ml-auto text-xs text-zinc-500 flex items-center">Total estimado: ${otForm.total||0} • Interconectado con cliente/vehículo/bahía</div>
                  </div>
                </div>
              )}
            </div>
          )}

          {activeModule==='presupuestos' && (
            <div className="space-y-4">
              <div className="flex justify-between"><h1 className="text-2xl font-black">Presupuestos</h1><button onClick={()=>setShowPresupuestoModal(true)} className="bg-[#7A1C1C] text-white px-4 py-2 rounded-xl font-bold text-sm">+ Nuevo presupuesto</button></div>
              <div className="grid md:grid-cols-2 gap-3">
                {presupuestos.map(p=>{const cl=getClient(p.clienteId); return <div key={p.id} className="bg-white border rounded-2xl p-4"><div className="flex justify-between"><div className="font-bold">{p.id} - {cl?.nombre}</div><span className={`text-xs px-2 py-1 rounded-full ${p.aprobado?'bg-green-100 text-green-700':'bg-yellow-100 text-yellow-700'}`}>{p.aprobado?'Aprobado':'Pendiente'}</span></div><div className="text-sm mt-1">Total: ${p.total} • Validez {p.validez}</div><div className="flex gap-2 mt-3"><button onClick={()=>setPresupuestos(presupuestos.map(x=> x.id===p.id? {...x, aprobado:!x.aprobado}:x))} className="border rounded-xl px-3 py-1 text-xs font-bold">{p.aprobado?'Desaprobar':'Aprobar digital'}</button><button onClick={()=>{const newOT: OT={ id:'OT-'+Math.floor(1000+Math.random()*9000), clienteId:p.clienteId, vehiculoId:p.vehiculoId, fecha:new Date().toISOString(), diagnostico:'Desde presupuesto '+p.id, descripcion:p.items.map((i:any)=>i.desc).join(', '), tiempoEst:3, tiempoReal:0, mecanico:MECHANICS[0], prioridad:'media', estado:'pendiente', bahia:1, checklist: CHECKLIST_BASE.map((n,i)=>({id:i.toString(), nombre:n, valor:'' as any})), danos:[], fotos:{antes:[], durante:[], despues:[]}, firmaCliente:'', firmaTecnico:'', total:p.total}; setOts([newOT, ...ots]); alert('Convertido a OT '+newOT.id); setActiveModule('ordenes');}} className="bg-[#7A1C1C] text-white rounded-xl px-3 py-1 text-xs font-bold">Convertir a OT</button></div></div>})}
              </div>
            </div>
          )}

          {activeModule==='inventario' && (
            <div className="space-y-4">
              <div className="flex justify-between"><h1 className="text-2xl font-black">Inventario & Almacén</h1><button onClick={()=>{const nombre=prompt('Nombre pieza'); if(!nombre) return; const sku=prompt('SKU')||'SKU-'+Date.now(); setParts([{id:'p'+Date.now(), nombre, sku, stock:5, min:3, ubicacion:'A1-01', precio:500}, ...parts]);}} className="bg-[#7A1C1C] text-white px-4 py-2 rounded-xl text-sm font-bold">+ Pieza</button></div>
              <div className="bg-white border rounded-2xl w-full max-w-full overflow-x-auto"><div className="min-w-[640px]"><table className="w-full text-sm"><thead className="bg-zinc-50 text-xs uppercase"><tr><th className="text-left p-3">Pieza</th><th className="p-3">SKU</th><th className="p-3">Stock</th><th className="p-3">Ubicación</th><th className="p-3">Precio</th><th className="p-3">Estado</th></tr></thead><tbody>{parts.map(p=> <tr key={p.id} className="border-t"><td className="p-3 font-medium">{p.nombre}</td><td className="p-3">{p.sku}</td><td className="p-3"><div className="flex items-center gap-2"><button onClick={()=>setParts(parts.map(x=> x.id===p.id? {...x, stock: Math.max(0,x.stock-1)}:x))} className="w-6 h-6 border rounded">-</button><span className="font-bold">{p.stock}</span><button onClick={()=>setParts(parts.map(x=> x.id===p.id? {...x, stock:x.stock+1}:x))} className="w-6 h-6 border rounded">+</button></div></td><td className="p-3">{p.ubicacion}</td><td className="p-3">${p.precio}</td><td className="p-3">{p.stock<=p.min? <span className="bg-red-100 text-red-700 px-2 py-1 rounded-full text-xs font-bold">Bajo mínimo</span>:<span className="bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs">OK</span>}</td></tr>)}</tbody></table></div></div>
            </div>
          )}

          {activeModule==='proveedores' && (
            <div className="space-y-4"><h1 className="text-2xl font-black">Proveedores & Compras</h1><div className="grid md:grid-cols-2 gap-3">{suppliers.map(s=> <div key={s.id} className="bg-white border rounded-2xl p-4"><div className="font-bold">{s.nombre}</div><div className="text-xs text-zinc-600 mt-1">{s.especialidad} • {s.telefono} • {s.email}</div><div className="mt-2 text-xs bg-zinc-50 p-2 rounded-xl">Comparativa precios: Filtro aceite Diésel $320 vs $350 • Última compra: 2024-06-10</div></div>)}</div></div>
          )}

          {activeModule==='personal' && (
            <div className="space-y-4"><h1 className="text-2xl font-black">Personal / Mecánicos</h1><div className="grid md:grid-cols-2 lg:grid-cols-4 gap-3">{employees.map(e=> <div key={e.id} className="bg-white border rounded-2xl p-4"><div className="w-10 h-10 bg-[#7A1C1C] text-white rounded-full flex items-center justify-center font-bold">{e.nombre[0]}</div><div className="font-bold mt-2">{e.nombre}</div><div className="text-xs text-zinc-600">{e.rol} • {e.especialidad} • {e.horario}</div><div className="mt-2 text-xs">Productividad: <div className="h-1.5 bg-zinc-100 rounded-full mt-1"><div className="h-full bg-green-600" style={{width:e.productividad+'%'}}/></div></div><div className="text-xs mt-2">Comisiones: ${e.comisiones}</div></div>)}</div></div>
          )}

          {activeModule==='tiempos' && (
            <div className="space-y-4"><h1 className="text-2xl font-black">Control Tiempos & Mano Obra</h1><div className="bg-white border rounded-2xl p-4"><table className="w-full text-sm"><thead><tr className="text-xs text-zinc-500 text-left"><th className="p-2">OT</th><th className="p-2">Mecánico</th><th className="p-2">Est</th><th className="p-2">Real</th><th className="p-2">Eficiencia</th></tr></thead><tbody>{ots.map(o=> <tr key={o.id} className="border-t"><td className="p-2 font-bold">{o.id}</td><td className="p-2">{o.mecanico}</td><td className="p-2">{o.tiempoEst}h</td><td className="p-2">{o.tiempoReal||'-'}h</td><td className="p-2">{o.tiempoReal? Math.round((o.tiempoEst/o.tiempoReal)*100)+'%':'-'} </td></tr>)}</tbody></table></div><div className="bg-white border rounded-2xl p-4"><h3 className="font-bold text-sm">Tarifas mano obra</h3><div className="text-xs mt-2 grid grid-cols-3 gap-2"><div className="border rounded-xl p-2">Diésel: $450/h</div><div className="border rounded-xl p-2">Gasolina: $380/h</div><div className="border rounded-xl p-2">Eléctrico: $500/h</div></div></div></div>
          )}

          {activeModule==='facturacion' && (
            <div className="space-y-4"><h1 className="text-2xl font-black">Facturación & Cobros</h1><div className="bg-white border rounded-2xl p-4 overflow-auto"><table className="w-full text-sm"><thead className="text-xs text-zinc-500 text-left"><tr><th className="p-2">Factura</th><th className="p-2">Cliente</th><th className="p-2">Total</th><th className="p-2">Estado</th><th className="p-2">Pago</th><th className="p-2">TPV</th></tr></thead><tbody>{facturas.map(f=> <tr key={f.id} className="border-t"><td className="p-2 font-bold">{f.id}</td><td className="p-2">{f.cliente}</td><td className="p-2">${f.total}</td><td className="p-2"><span className={`px-2 py-1 rounded-full text-xs ${f.estado==='pendiente'?'bg-yellow-100':'bg-green-100'}`}>{f.estado}</span></td><td className="p-2">{f.pago}</td><td className="p-2"><button onClick={()=>{setFacturas(facturas.map(x=> x.id===f.id? {...x, estado:'cobrada'}:x));}} className="bg-[#7A1C1C] text-white px-2 py-1 rounded-lg text-xs">Cobrar TPV</button></td></tr>)}</tbody></table></div></div>
          )}

          {activeModule==='bahias' && (
            <div className="space-y-4"><h1 className="text-2xl font-black">Gestión Bahías / Recursos</h1><div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">{[1,2,3,4].map(n=>{const ot=ots.find(o=>o.bahia===n && o.estado!=='entregado'); return <div key={n} className="bg-white border rounded-2xl p-4"><div className="flex justify-between"><span className="font-black">Elevador {n}</span><span className={`text-xs px-2 py-1 rounded-full ${ot?'bg-[#7A1C1C] text-white':'bg-green-100 text-green-700'}`}>{ot?'Ocupado':'Libre'}</span></div><div className="mt-3 aspect-[4/3] bg-zinc-100 rounded-xl flex items-center justify-center text-4xl">🏗️</div><div className="text-xs mt-2">{ot? `${ot.id} - ${getVehicle(ot.vehiculoId)?.matricula} - ${ot.mecanico}`:'Disponible para reserva herramienta especial'}</div></div>})}</div></div>
          )}

          {activeModule==='movil' && (
            <div className="space-y-4"><h1 className="text-2xl font-black">Módulo Móvil Técnico</h1><div className="bg-white border rounded-2xl p-4"><select className="border rounded-xl px-3 py-2 text-sm" defaultValue={MECHANICS[0]}>{MECHANICS.map(m=> <option key={m}>{m}</option>)}</select></div><div className="grid gap-3">{ots.filter(o=>o.estado==='en proceso').map(o=>{const v=getVehicle(o.vehiculoId); return <div key={o.id} className="bg-white border rounded-2xl p-4"><div className="font-bold">{o.id} - {v?.marca} {v?.matricula}</div><div className="text-xs">{o.descripcion}</div><div className="flex gap-2 mt-3"><button className="flex-1 bg-[#7A1C1C] text-white rounded-xl py-2 text-xs font-bold">Registrar tiempo</button><button className="flex-1 border rounded-xl py-2 text-xs font-bold">Subir foto</button></div></div>})}</div></div>
          )}

         {activeModule==='informes' && (
            <div className="space-y-4">
              <h1 className="text-2xl font-black">Informes & KPIs</h1>
              <div className="grid lg:grid-cols-2 gap-4">
                <div className="bg-white border rounded-2xl p-5">
                  <h3 className="font-bold mb-3">Servicios más demandados</h3>
                  <div className="space-y-2">{SERVICES.map((s,i)=> <div key={s} className="flex items-center gap-2"><span className="text-xs w-32">{s}</span><div className="flex-1 h-2 bg-zinc-100 rounded-full"><div className="h-full bg-[#7A1C1C] rounded-full" style={{width: `${80-i*8}%`}}/></div><span className="text-xs font-bold">{12-i*2}</span></div>)}</div>
                </div>
                <div className="bg-white border rounded-2xl p-5">
                  <h3 className="font-bold mb-3">Ranking mecánicos</h3>
                  <div className="space-y-2">{employees.sort((a,b)=>b.productividad-a.productividad).map(e=> <div key={e.id} className="flex justify-between items-center border rounded-xl px-3 py-2"><span className="font-bold text-sm">{e.nombre}</span><span className="text-xs bg-zinc-100 px-2 py-1 rounded-full">{e.productividad}% eficiencia</span></div>)}</div>
                </div>
              </div>
              <div className="bg-white border rounded-2xl p-5"><h3 className="font-bold mb-2">Exportación</h3><button onClick={()=>{const data=JSON.stringify({clients,vehicles,ots,parts}, null,2); const blob=new Blob([data], {type:'application/json'}); const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download='informe-dg.json'; a.click();}} className="bg-zinc-900 text-white px-4 py-2 rounded-xl text-sm font-bold">Exportar Excel/JSON</button></div>
            </div>
          )}

          {activeModule==='config' && (
            <div className="space-y-4"><h1 className="text-2xl font-black">Configuración & Administración</h1>
              <div className="grid lg:grid-cols-2 gap-4">
                <div className="bg-white border rounded-2xl p-5"><h3 className="font-bold mb-3">Parámetros taller</h3><div className="space-y-2 text-sm"><div className="flex justify-between border rounded-xl px-3 py-2"><span>Tarifa Diésel</span><span className="font-bold">$450/h</span></div><div className="flex justify-between border rounded-xl px-3 py-2"><span>Tarifa Gasolina</span><span className="font-bold">$380/h</span></div><div className="flex justify-between border rounded-xl px-3 py-2"><span>IVA</span><span className="font-bold">16%</span></div><div className="flex justify-between border rounded-xl px-3 py-2"><span>Serie facturación</span><span className="font-bold">F-2024</span></div></div></div>
                <div className="bg-white border rounded-2xl p-5"><h3 className="font-bold mb-3">Usuarios y roles</h3><div className="space-y-2 text-sm"><div className="border rounded-xl px-3 py-2 flex justify-between"><span>Admin - Propietario</span><span className="bg-[#7A1C1C] text-white px-2 py-0.5 rounded-full text-xs">Todos</span></div><div className="border rounded-xl px-3 py-2 flex justify-between"><span>Mecánico</span><span className="bg-zinc-100 px-2 py-0.5 rounded-full text-xs">OTs, Tiempos</span></div><div className="border rounded-xl px-3 py-2 flex justify-between"><span>Recepción</span><span className="bg-zinc-100 px-2 py-0.5 rounded-full text-xs">Clientes, Citas</span></div></div></div>
                <div className="bg-white border rounded-2xl p-5 lg:col-span-2"><h3 className="font-bold mb-3">Backup / Seguridad</h3><div className="flex flex-wrap gap-2"><button onClick={()=>{const data=JSON.stringify({clients,vehicles,ots,appointments,parts,presupuestos}, null,2); const blob=new Blob([data], {type:'application/json'}); const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download=`backup-dg-${new Date().toISOString().slice(0,10)}.json`; a.click();}} className="bg-[#7A1C1C] text-white px-4 py-2 rounded-xl text-sm font-bold">Exportar JSON Backup</button><label className="border px-4 py-2 rounded-xl text-sm font-bold cursor-pointer">Importar JSON<input type="file" accept=".json" className="hidden" onChange={e=>{const file=e.target.files?.[0]; if(!file) return; const reader=new FileReader(); reader.onload=ev=>{try{const d=JSON.parse(ev.target?.result as string); if(d.clients) setClients(d.clients); if(d.vehicles) setVehicles(d.vehicles); if(d.ots) setOts(d.ots); if(d.appointments) setAppointments(d.appointments); alert('Backup importado');}catch{alert('JSON inválido');}}; reader.readAsText(file);}}/></label><button onClick={()=>{if(confirm('Borrar todos los datos?')){localStorage.clear(); location.reload();}}} className="border border-red-200 text-red-600 px-4 py-2 rounded-xl text-sm font-bold">Borrar datos</button></div><div className="text-xs text-zinc-500 mt-3">Integraciones: WhatsApp API, Email SMTP, Diagnosis OBD - configuración simulada lista para conectar.</div></div>
              </div>
            </div>
          )}

        </main>
      </div>

      {/* Modals */}
      {showClientModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg p-5 space-y-3 max-h-[90vh] overflow-auto">
            <h3 className="font-black text-lg">{editingClient?'Editar':'Nuevo'} Cliente</h3>
            <div className="grid grid-cols-2 gap-2">
              <div className="col-span-2"><label className="text-xs font-bold">Nombre / Razón social</label><input value={clientForm.nombre||''} onChange={e=>setClientForm({...clientForm, nombre:e.target.value})} className="w-full border rounded-xl px-3 py-2 text-sm"/></div>
              <div><label className="text-xs font-bold">Tipo</label><select value={clientForm.tipo} onChange={e=>setClientForm({...clientForm, tipo:e.target.value as any})} className="w-full border rounded-xl px-3 py-2 text-sm"><option value="particular">Particular</option><option value="empresa">Empresa</option></select></div>
              <div><label className="text-xs font-bold">Teléfono (con lada)</label><input value={clientForm.telefono||''} onChange={e=>setClientForm({...clientForm, telefono:e.target.value})} className="w-full border rounded-xl px-3 py-2 text-sm" placeholder="521..."/></div>
              <div className="col-span-2"><label className="text-xs font-bold">Email</label><input value={clientForm.email||''} onChange={e=>setClientForm({...clientForm, email:e.target.value})} className="w-full border rounded-xl px-3 py-2 text-sm"/></div>
              <div className="col-span-2"><label className="text-xs font-bold">Dirección</label><input value={clientForm.direccion||''} onChange={e=>setClientForm({...clientForm, direccion:e.target.value})} className="w-full border rounded-xl px-3 py-2 text-sm"/></div>
              <div><label className="text-xs font-bold">RFC</label><input value={clientForm.rfc||''} onChange={e=>setClientForm({...clientForm, rfc:e.target.value})} className="w-full border rounded-xl px-3 py-2 text-sm"/></div>
              <div><label className="text-xs font-bold">Etiquetas</label><input value={(clientForm.tags||[]).join(',')} onChange={e=>setClientForm({...clientForm, tags:e.target.value.split(',').map(t=>t.trim()).filter(Boolean)})} className="w-full border rounded-xl px-3 py-2 text-sm" placeholder="VIP, Diésel"/></div>
              <div className="col-span-2"><label className="text-xs font-bold">Notas / Preferencias</label><textarea value={clientForm.notas||''} onChange={e=>setClientForm({...clientForm, notas:e.target.value})} className="w-full border rounded-xl px-3 py-2 text-sm" rows={2}/></div>
            </div>
            <div className="flex gap-2 pt-2"><button onClick={saveClient} className="flex-1 bg-[#7A1C1C] text-white rounded-xl py-2 font-bold">Guardar</button><button onClick={()=>setShowClientModal(false)} className="flex-1 border rounded-xl py-2 font-bold">Cancelar</button></div>
          </div>
        </div>
      )}

      {showVehicleModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg p-5 space-y-3 max-h-[90vh] overflow-auto">
            <h3 className="font-black text-lg">{editingVehicle?'Editar':'Nuevo'} Vehículo</h3>
            <div className="grid grid-cols-2 gap-2">
              <div className="col-span-2"><label className="text-xs font-bold">Cliente asociado</label><select value={vehicleForm.clienteId||''} onChange={e=>setVehicleForm({...vehicleForm, clienteId:e.target.value})} className="w-full border rounded-xl px-3 py-2 text-sm"><option value="">Seleccionar cliente</option>{clients.map(c=> <option key={c.id} value={c.id}>{c.nombre}</option>)}</select></div>
              <div><label className="text-xs font-bold">Marca</label><input value={vehicleForm.marca||''} onChange={e=>setVehicleForm({...vehicleForm, marca:e.target.value})} className="w-full border rounded-xl px-3 py-2 text-sm"/></div>
              <div><label className="text-xs font-bold">Modelo</label><input value={vehicleForm.modelo||''} onChange={e=>setVehicleForm({...vehicleForm, modelo:e.target.value})} className="w-full border rounded-xl px-3 py-2 text-sm"/></div>
              <div><label className="text-xs font-bold">Matrícula</label><input value={vehicleForm.matricula||''} onChange={e=>setVehicleForm({...vehicleForm, matricula:e.target.value})} className="w-full border rounded-xl px-3 py-2 text-sm"/></div>
              <div><label className="text-xs font-bold">VIN</label><input value={vehicleForm.vin||''} onChange={e=>setVehicleForm({...vehicleForm, vin:e.target.value})} className="w-full border rounded-xl px-3 py-2 text-sm"/></div>
              <div><label className="text-xs font-bold">Año</label><input type="number" value={vehicleForm.anio||''} onChange={e=>setVehicleForm({...vehicleForm, anio:parseInt(e.target.value)})} className="w-full border rounded-xl px-3 py-2 text-sm"/></div>
              <div><label className="text-xs font-bold">Color</label><input value={vehicleForm.color||''} onChange={e=>setVehicleForm({...vehicleForm, color:e.target.value})} className="w-full border rounded-xl px-3 py-2 text-sm"/></div>
              <div className="col-span-2"><label className="text-xs font-bold">Kilometraje</label><input type="number" value={vehicleForm.km||''} onChange={e=>setVehicleForm({...vehicleForm, km:parseInt(e.target.value)})} className="w-full border rounded-xl px-3 py-2 text-sm"/></div>
            </div>
            <div className="flex gap-2 pt-2"><button onClick={saveVehicle} className="flex-1 bg-[#7A1C1C] text-white rounded-xl py-2 font-bold">Guardar</button><button onClick={()=>setShowVehicleModal(false)} className="flex-1 border rounded-xl py-2 font-bold">Cancelar</button></div>
          </div>
        </div>
      )}

      {showAppointmentModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-md p-5 space-y-3">
            <h3 className="font-black">Nueva Cita</h3>
            <select value={appointmentForm.clienteId||''} onChange={e=>setAppointmentForm({...appointmentForm, clienteId:e.target.value})} className="w-full border rounded-xl px-3 py-2 text-sm"><option value="">Cliente</option>{clients.map(c=> <option key={c.id} value={c.id}>{c.nombre}</option>)}</select>
            <select value={appointmentForm.vehiculoId||''} onChange={e=>setAppointmentForm({...appointmentForm, vehiculoId:e.target.value})} className="w-full border rounded-xl px-3 py-2 text-sm"><option value="">Vehículo</option>{vehicles.filter(v=> !appointmentForm.clienteId || v.clienteId===appointmentForm.clienteId).map(v=> <option key={v.id} value={v.id}>{v.marca} {v.matricula}</option>)}</select>
            <div className="grid grid-cols-2 gap-2"><input type="date" value={appointmentForm.fecha||''} onChange={e=>setAppointmentForm({...appointmentForm, fecha:e.target.value})} className="border rounded-xl px-3 py-2 text-sm"/><input type="time" value={appointmentForm.hora||''} onChange={e=>setAppointmentForm({...appointmentForm, hora:e.target.value})} className="border rounded-xl px-3 py-2 text-sm"/></div>
            <select value={appointmentForm.servicio||''} onChange={e=>setAppointmentForm({...appointmentForm, servicio:e.target.value})} className="w-full border rounded-xl px-3 py-2 text-sm">{SERVICES.map(s=> <option key={s} value={s}>{s}</option>)}</select>
            <select value={appointmentForm.bahia} onChange={e=>setAppointmentForm({...appointmentForm, bahia:parseInt(e.target.value)})} className="w-full border rounded-xl px-3 py-2 text-sm">{[1,2,3,4].map(n=> <option key={n} value={n}>Bahía {n}</option>)}</select>
            <div className="flex gap-2"><button onClick={saveAppointment} className="flex-1 bg-[#7A1C1C] text-white rounded-xl py-2 font-bold">Agendar</button><button onClick={()=>setShowAppointmentModal(false)} className="flex-1 border rounded-xl py-2 font-bold">Cancelar</button></div>
          </div>
        </div>
      )}

      {showPresupuestoModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-md p-5 space-y-3">
            <h3 className="font-black">Nuevo Presupuesto</h3>
            <select id="pres-cli" className="w-full border rounded-xl px-3 py-2 text-sm"><option>Seleccionar cliente</option>{clients.map(c=> <option key={c.id} value={c.id}>{c.nombre}</option>)}</select>
            <input id="pres-total" type="number" placeholder="Total $" className="w-full border rounded-xl px-3 py-2 text-sm"/>
            <div className="flex gap-2"><button onClick={()=>{const sel=(document.getElementById('pres-cli') as HTMLSelectElement).value; const tot=parseInt((document.getElementById('pres-total') as HTMLInputElement).value||'0'); if(!sel||!tot) return alert('Faltan datos'); setPresupuestos([{id:'P-'+Math.floor(1000+Math.random()*9000), clienteId:sel, vehiculoId:vehicles.find(v=>v.clienteId===sel)?.id||'', total:tot, validez:new Date(Date.now()+7*86400000).toISOString().slice(0,10), aprobado:false, items:[{desc:'Servicio', qty:1, price:tot}]}, ...presupuestos]); setShowPresupuestoModal(false);}} className="flex-1 bg-[#7A1C1C] text-white rounded-xl py-2 font-bold">Crear</button><button onClick={()=>setShowPresupuestoModal(false)} className="flex-1 border rounded-xl py-2 font-bold">Cancelar</button></div>
          </div>
        </div>
      )}

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;900&display=swap');
        *{font-family:Inter, system-ui, -apple-system, sans-serif}
        ::-webkit-scrollbar{width:6px;height:6px}
        ::-webkit-scrollbar-thumb{background:#C0C0C0;border-radius:10px}
      `}</style>
    </div>
  );
}
